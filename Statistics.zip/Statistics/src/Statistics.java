import java.io.*;
import java.util.*;

public class Statistics {

    public String preProcessing(String line, BufferedReader reader) throws IOException {

        String[] stop_words = {"the","and","a","on","is","all","of","to"};
        int words = 0;
        int sentences = 0;
        String book = "";
        // reading a file
        while ((line = reader.readLine()) != null) {

            line = line.replaceAll("[-=,!?‘’.:#''…;“”\"\"–«»()/—]+", " ");//character deleting
            line = line.replaceAll("[0-9]+", "");//number deleting
            line = line.toLowerCase();//to lowercase
            String[] wordss = line.split(" ");

            // to count number of words in the book
            words += wordss.length;

            for (int k = 0; k < wordss.length; k++) {
                for (int w = 0; w < stop_words.length; w++) {
                    if (wordss[k].equals(stop_words[w])) {
                        wordss[k] = wordss[k].replaceAll(wordss[k], "");
                    }
                }
            }
            String[] sent = line.split("[!?.:]+");
            // to count number of sentences in the book
            sentences += sent.length;

            book = book + line;
        }
        // number of words and sentences
        System.out.println("Number of words in given txt file is equal to: " + words);
        System.out.println("Number of sentences in given txt file is equal to: " + sentences);
        return book;
    }

    public int countOccurence(String input, String word) {
        String array[] = input.split(" ");

        int count = 0;
        for (int i = 0; i < array.length; i++) {
            if (word.equals(array[i]))
                count++;
        }
        return count;
    }

//    public String getLongestWords() throws FileNotFoundException {
//
//        String longestWord = "";
//        String current;
//        Scanner scan = new Scanner(new File("harry.txt"));
//
//        while (scan.hasNext()) {
//            current = scan.next();
//            current.replaceAll("[0-9]+", "");//number deleting
//            current.toLowerCase();
//
//            if ((current.length() > longestWord.length()) && (!current.matches(".*\\d.*"))) {
//                longestWord = current;
//            }
//
//        }
//        longestWord.replaceAll("[^a-zA-Z ]", "").split("\\s+");
//        //to lowercase
//        return longestWord;
//    }

    public  Set<CharSequence> palindromes(String input) {
        if (input.length() <= 2) {
            return Collections.emptySet();
        }
        Set<CharSequence> output = new HashSet<CharSequence>();
        int length = input.length();
        for (int i = 1; i <= length; i++) {
            for (int j = i - 1, k = i; j >= 0 && k < length; j--, k++) {
                if (input.charAt(j) == input.charAt(k)) {
                    output.add(input.subSequence(j, k + 1));
                } else {
                    break;
                }
            }
        }
        return output;
    }
    
    public static void main(String[] args) throws IOException {

        File file = new File("harry.txt");
        FileInputStream fileStream = new FileInputStream(file);
        InputStreamReader input = new InputStreamReader(fileStream);
        BufferedReader reader = new BufferedReader(input);
        String line = "";

        Statistics stats = new Statistics();

        String inp = stats.preProcessing(line, reader);
        int occ = stats.countOccurence(inp, "harry");
        //String longestWord = stats.getLongestWords();
        Set<CharSequence> palindromes = stats.palindromes(inp);
        //System.out.println("The longest word is: " + longestWord);
        System.out.println("Occurence of word harry is: " + occ);
        System.out.println(palindromes);

        // to get the largest word
        System.out.println(Arrays.stream(inp.split(" ")).max(Comparator.comparingInt(String::length)).orElse(null));
    }
}
